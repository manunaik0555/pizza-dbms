<div class="footer container-fluid bg-dark text-light">
    <p class="text-center py-2 mb-0">team @ conqueror <a href="https://github.com/manunaik0555" target="_blank" rel="noopener noreferrer">@ MANU NAIK </a></p>
</div>
